# CURRICULO-ALT


## Seções:
<hr/>
- header
- - texto: curriculo;
<br/>
<hr/>

### SECTIONS-LIST:
<hr/>

#### LINHA 1:

- Dados gerais;
- Formaçao;  
- Atuaçao;
- Projetos;
- Produções;
- Patentes;
- Registros.       

<hr/>


#### LINHA 2:

- Inovaçao;
- Educaçao;  
- Eventos;
- Orientações;
- Bancas;  
- Citações.       

<hr/>

### CONTENT:


