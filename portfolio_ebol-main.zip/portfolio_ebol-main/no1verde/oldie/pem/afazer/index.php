<!DOCTYPE html>
<html>

	<head>
		<link rel="stylesheet" href="./style.css"/>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
	</head>
	<body>
		<div id="side1-PC">
	        <a href="#">
				<div id="box-link-5-PC">

					<div id="box-img-9-PC">
						<img id="img-PC" src="../img_geral/ppafz.png"/>	
					</div>

					<div id="box-texto-10-PC">
						<img id="img-2-PC" src="../img_geral/afz.png"/>
					</div>	
				</div>
			</a>
	        
			
	        <a href="#">
				<div id="box-1">
					<div id="title-img">
						<img id="img-PC" src="../img_geral/cell.png"/>
					</div>

					<div id="icon-img">
						<img id="img-PC" src="../img_geral/cellsv.png"/>
					</div>

					<div id="about-img">
					<img id="img-2-PC" src="../img_geral/diary.png"/>
					</div>

				</div>
			</a>

            <a href="#">
				<div id="box-2">
					<div id="title-img">
						<img id="img-PC" src="../img_geral/cell.png"/>
					</div>

					<div id="icon-img">
						<img id="img-PC" src="../img_geral/cellsv.png"/>
					</div>

					<div id="about-img">
					<img id="img-2-PC" src="../img_geral/cli-stock.png"/>
					</div>

				</div>
			</a>

			

			

			

			

			
		

			

		</div>

		<div id="side2-PC">
			<a href="../home/index.php">
			 
				<div id="title-link-PC">
					 <div id="box-img-1-PC">
						<img id="img-PC" src="../img_geral/pp.png"/>	
					 </div>

					 <div id="box-texto-2-PC">
						<img id="img-2-PC" src="../img_geral/pp-2.png"/>
					 </div>				
				</div>
			</a>

			<img id="cross-perfil-PC" src="../img_geral/design/122363928_3442428835835863_5806509536294564215_n.jpg"/>

			<div id="letter-box-PC">
				<a href="../sobre/index.php">
				     <div id="box-link-1-PC">

						 <div id="box-img-1-PC">
							<img id="img-PC" src="../img_geral/sobre.png"/>	
						 </div>

						 <div id="box-texto-2-PC">
							<img id="img-2-PC" src="../img_geral/sobre-2.png"/>	
						 </div>	
					 </div>
				</a>

				<a href="../xp-lv-1/index.php">
	                <div id="box-link-2-PC">
						 <div id="box-img-3-PC">
							<img id="img-PC" src="../img_geral/xp.png"/>	
						 </div>
						
						 <div id="box-texto-4-PC">
							<img id="img-2-PC" src="../img_geral/xp-2.png"/>	
						 </div>
					</div>
				</a>

                <a href="../edu/index.php">
	                <div id="box-link-3-PC">
						 <div id="box-img-5-PC">
							<img id="img-PC" src="../img_geral/edu.png"/>	
						 </div>

						 <div id="box-texto-6-PC">
							<img id="img-2-PC" src="../img_geral/edu-2.png"/>	
						 </div>
					</div>
                </a>
            </div>
        </div>

	</body>



</html>